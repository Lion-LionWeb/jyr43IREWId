
var qaipalBtn = document.querySelector(".quickactions .quick-popup-content .link");
if(qaipalBtn) {
qaipalBtn.addEventListener("click", function (e) {
e.preventDefault();
document.getElementsByClassName("widget-side__opener-icon")[0].click();
});
}

var qaipalBtn = document.querySelector(".quickactions .quick-popup-content .link");
if(qaipalBtn) {
qaipalBtn.addEventListener("click", function (e) {
e.preventDefault();
document.getElementsByClassName("widget-side__opener-icon")[0].click();
});
}
